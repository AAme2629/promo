// add anywhere:
#define __PROMO_CODE__

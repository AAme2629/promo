// find:
	QID_PROTECT_CHILD,

// paste below:
#ifdef __PROMO_CODE__
	QID_CHECK_PROMO,
	QID_SAVE_PROMO,
#endif

// find:
typedef struct SUseTime
{
	DWORD	dwLoginKey;
	char        szLogin[LOGIN_MAX_LEN+1];
	DWORD       dwUseSec;
	char        szIP[MAX_HOST_LENGTH+1];
} TUseTime;

// paste below:
#ifdef __PROMO_CODE__
typedef struct SPromoItem
{
	DWORD	item_vnum;
	DWORD	item_count;
} TPromoItem;
#endif
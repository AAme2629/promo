// find:
		int				GetSyncHackCount() { return m_iSyncHackCount; }

// paste below:
#ifdef __PROMO_CODE__
	public:
		bool			CanActPromoCode() { return m_dwNextPromoCodeActTime - get_global_time() < 0; }
		void			SetActPromoCode() { m_dwNextPromoCodeActTime = get_global_time() + 5; }
	private:
		DWORD			m_dwNextPromoCodeActTime;
#endif
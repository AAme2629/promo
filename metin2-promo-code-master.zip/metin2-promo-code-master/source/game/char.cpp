// find:
#ifdef __PET_SYSTEM__
	m_petSystem = 0;
	m_bIsPet = false;
#endif

// paste below:
#ifdef __PROMO_CODE__
	m_dwNextPromoCodeActTime = 0;
#endif
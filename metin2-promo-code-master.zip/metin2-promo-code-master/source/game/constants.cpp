// find:
		case QID_PCBANG_IP_LIST_SELECT:
			[...]
			break;

// paste below:
#ifdef __PROMO_CODE__
		case QID_CHECK_PROMO:
		{
			// check if player actually exists
			LPCHARACTER ch = CHARACTER_MANAGER::instance().FindByPID(qi->dwIdent);

			if (!ch || !ch->GetDesc())
				break;

			DWORD pid = ch->GetPlayerID();

			sys_log(0, "Player %s [%d] tries to use promo code %s", ch->GetName(), pid, qi->pvData);

			if (pMsg->uiSQLErrno != 0)
			{
				sys_err("Failed to load promo code, error code %d", pMsg->uiSQLErrno);
				break;
			}

			if (!pMsg->Get())
			{
				sys_err("Promo code query returned without data");
				break;
			}

			// check if code has any items 
			if (pMsg->Get()->uiNumRows > 0)
			{
				MYSQL_ROW row;

				struct promo_table
				{
					int	id;
					char	code[32 + 1];
					int	item_vnum;
					int	item_count;
					int	receiver;
				};

				std::vector<struct promo_table> vec_promo;
				auto i = 0;

				vec_promo.resize(pMsg->Get()->uiNumRows);

				while (row = mysql_fetch_row(pMsg->Get()->pSQLResult))
				{
					auto col = 0;

					auto table = &vec_promo[i];

					str_to_number(table->id, row[col++]);
					strlcpy(table->code, row[col++], sizeof(table->code));
					str_to_number(table->item_vnum, row[col++]);
					str_to_number(table->item_count, row[col++]);
					str_to_number(table->receiver, row[col++]);

					sys_log(1, "PROMO ID [%d], CODE [%s], ITEM_VNUM [%d], ITEM_COUNT [%d], RECEIVER [%d]", table->id, table->code, table->item_vnum, table->item_count, table->receiver);

					i++;
				}

				int index = 0;
				char code[32 + 1];
				memcpy(code, qi->pvData, sizeof(code));

				struct promo_table item;

				if (vec_promo.size() > 1)
				{
					bool received_promo = false;

					for (int i = 0; i < vec_promo.size(); i++)
					{
						auto it = &vec_promo[i];

						if (!strcmp(it->code, code))
							memcpy(&item, it, sizeof(item));
					}
				
					for (int i = 0; i < vec_promo.size(); i++)
					{
						auto it = &vec_promo[i];
							
						if (it->id == item.id && it->receiver == pid)
							received_promo = true;
					}
					
					if (received_promo)
					{
						ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("promo you already received from this promo"));
						break;
					}
				}
				else
				{
					item = vec_promo[0];
					
					if (strcmp(item.code, code))
					{
						ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("promo code doesn't exist"));
						break;
					}
				}

				sys_log(0, "PROMO ID [%d], CODE [%s], ITEM_VNUM [%d], ITEM_COUNT [%d], RECEIVER [%d]", item.id, item.code, item.item_vnum, item.item_count, item.receiver);

				if (item.receiver)
				{
					if (item.receiver == pid)
						ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("promo you already received from this promo"));
					else
						ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("promo someone already received from this promo"));
					break;
				}

				auto save = M2_NEW TPromoItem;
				save->item_vnum = item.item_vnum;
				save->item_count = item.item_count;

				ReturnQuery(QID_SAVE_PROMO, pid, save, "UPDATE `promo_table` SET `receiver` = %d WHERE `promo_id` = %d AND code = '%s'",
					pid, item.id, item.code);
			}
			else
			{
				ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("promo code doesn't exist"));
			}
		}
			break;

		case QID_SAVE_PROMO:
		{
			// check if player actually exists
			LPCHARACTER ch = CHARACTER_MANAGER::instance().FindByPID(qi->dwIdent);

			if (!ch || !ch->GetDesc())
				break;

			sys_log(0, "Player %s used correct promo code", ch->GetName());

			if (pMsg->uiSQLErrno != 0)
			{
				sys_err("Failed to save promo code, error code %d", pMsg->uiSQLErrno);
				break;
			}

			if (!pMsg->Get())
			{
				sys_err("Promo code query returned without data");
				break;
			}

			if (pMsg->Get()->uiAffectedRows > 0)
			{
				auto item = (TPromoItem*) qi->pvData;
				ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("promo received an item"));
				ch->AutoGiveItem(item->item_vnum, item->item_count);
			}
			else
			{
				sys_err("failed to save data in database, wont't give an item");
			}
		}
			break;
#endif
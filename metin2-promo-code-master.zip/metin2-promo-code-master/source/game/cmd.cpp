// find:
ACMD (do_clear_affect);

// paste below:
#ifdef __PROMO_CODE__
ACMD(do_promo_code);
#endif

// find:
	{ "do_clear_affect", do_clear_affect, 	0, POS_DEAD,		GM_LOW_WIZARD},

// paste below:
#ifdef __PROMO_CODE__
	{ "promo_code", do_promo_code, 0, POS_DEAD, GM_PLAYER, },
#endif
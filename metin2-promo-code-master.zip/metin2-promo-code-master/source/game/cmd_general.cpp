// add at the end of the file:
#ifdef __PROMO_CODE__
ACMD(do_promo_code)
{
	char arg1[256];
	one_argument(argument, arg1, sizeof(arg1));

	if (!*arg1 || !strlen(arg1))
		return;

	if (strstr(arg1, ";"))
	{
		ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("promo sqli msg"));
		return;
	}

	if (!ch->CanActPromoCode())
	{
		ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("promo wait a few seconds"));
		return;
	}

	ch->SetActPromoCode();

	DBManager::instance().ReturnQuery(QID_CHECK_PROMO, ch->GetPlayerID(), arg1, "SELECT `promo_id`, `code`, `item_vnum`, `item_count`, `receiver` FROM `promo_table`"
		" WHERE `code` = '%s' OR `receiver` = %d", arg1, ch->GetPlayerID());
}
#endif
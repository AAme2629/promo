## find:
import localeInfo

## paste below:
import uipromocode

## find:
		self.wndGuildBuilding = None

## paste below:
		self.wndPromoCode = None

## find:
		self.dlgRefineNew = uiRefine.RefineDialogNew()
		self.dlgRefineNew.Hide()

## paste below:
		self.wndPromoCode = uipromocode.PromoCodeDialog()
		self.wndPromoCode.Hide()

## find:
		if self.wndItemSelect:
			self.wndItemSelect.Destroy()

## paste below:
		if self.wndPromoCode:
			self.wndPromoCode.Destroy()
			del self.wndPromoCode
## find:
		if self.wndExpandedTaskBar:
			self.wndExpandedTaskBar.Hide()

## paste below:
		if self.wndPromoCode:
			self.wndPromoCode.Hide()

## find:
		if self.wndExpandedTaskBar:
			hideWindows += self.wndExpandedTaskBar,

## paste below:
		hideWindows += self.wndPromoCode,

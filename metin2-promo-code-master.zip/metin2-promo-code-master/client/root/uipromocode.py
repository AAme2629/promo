import ui
import localeInfo
import uiCommon
import net

class PromoCodeDialog(ui.ScriptWindow):
    def __init__(self):
        ui.ScriptWindow.__init__(self)
        self.__questionDialog = None
        self.__LoadWindow()

    def __del__(self):
        ui.ScriptWindow.__del__(self)

    def __LoadWindow(self):
        try:
            pythonScriptLoader = ui.PythonScriptLoader()
            pythonScriptLoader.LoadScriptFile(self, "uiscript/promocodedialog.py")
        except:
            import exception
            exception.Abort("PromoCodeDialog.__LoadWindow.LoadObject")

        self.codeText = self.GetChild("code_text")
        self.codeValue = self.GetChild("code_value")
        self.acceptButton = self.GetChild("accept_button")

        self.codeValue.OnSetFocus = self.__OnCodeValueSetFocus
        self.codeValue.OnKillFocus = self.__OnCodeValueKillFocus

        self.acceptButton.SetEvent(ui.__mem_func__(self.__OnClickAcceptButton))

        self.GetChild("board").SetCloseEvent(self.Hide)

    def __OnCodeValueSetFocus(self):
        ui.EditLine.OnSetFocus(self.codeValue)
        self.codeText.Hide()

    def __OnCodeValueKillFocus(self):
        ui.EditLine.OnKillFocus(self.codeValue)
        if not len(self.codeValue.GetText()):
            self.codeText.Show()

    def __OnClickAcceptButton(self):
        text = self.codeValue.GetText()
        if not text:
            return

        self.__questionDialog = uiCommon.QuestionDialog()
        self.__questionDialog.SetText(localeInfo.PROMO_CODE_DO_YOU_USE % text)
        self.__questionDialog.SetAcceptEvent(lambda arg=True: self.__OnAnswer(arg))
        self.__questionDialog.SetCancelEvent(lambda arg=False: self.__OnAnswer(arg))
        self.__questionDialog.Open()

    def __OnAnswer(self, flag):
        self.__questionDialog.Close()
        self.__questionDialog = None

        text = self.codeValue.GetText()
        self.codeValue.SetText("")
        self.codeValue.KillFocus()

        if flag:

            if text:
                net.SendChatPacket("/promo_code %s" % text)

    def Destroy(self):
        self.Hide()
        self.ClearDictionary()

        if self.__questionDialog:
            self.__questionDialog.Close()
            self.__questionDialog = None

    def OnPressEscapeKey(self):
        self.Close()
        return True
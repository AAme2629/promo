## find:
        serverCommandList={
            [...]
		}

## paste below:
		if app.ENABLE_ITEM_RARITY:
			serverCommandList.update({
				"ChangeRarityClose"			: self.interface.ChangeRarityClose,
				"ChangeRarityOpen"			: self.interface.ChangeRarityOpen,
				"ChangeRarityAddMaterial"	: self.interface.ChangeRarityAddMaterial,
				"ChangeRarityRefresh"			: self.interface.ChangeRarityRefresh,
			})
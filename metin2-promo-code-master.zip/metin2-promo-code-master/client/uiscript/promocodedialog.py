import uiScriptLocale

ROOT_PATH = "d:/ymir work/ui/game/offlineshop/"

window = {
	"name" : "PromoCodeDialog",
	"style": ("movable", "float",),

	"x" : (SCREEN_WIDTH - 300) / 2,
	"y" : (SCREEN_HEIGHT - 170) / 2,

	"width": 300,
	"height": 170,

	"children" :
	(
		{
			"name" : "board",
			"type" : "board_with_titlebar",

			"style": ("attach",),

			"x" : 0,
			"y" : 0,

			"width" : 300,
			"height" : 170,

			"title" : uiScriptLocale.PROMO_CODE_TITLE,

			"children" :
			(
				{
					"name" : "input_wnd",
					"type" : "window",

					"x" : 0,
					"y" : 80,

					"horizontal_align" : "center",

					"width" : 200,
					"height" : 18,

					"children" : (
						{
							"name" : "board_left",
							"type" : "expanded_image",
							"style": ("ltr",),

							"x" : 0,
							"y" : 0,

							"image" : "d:/ymir work/ui/pattern/border_c_left.tga",
						},
						{
							"name" : "board_middle",
							"type" : "expanded_image",
							"style": ("ltr",),

							"x" : 21,
							"y" : 0,

							"rect" : (0.0, 0.0, 200.0 / 21.0 - 3.0, 0),

							"image" : "d:/ymir work/ui/pattern/border_c_middle.tga",
						},
						{
							"name" : "board_right",
							"type" : "expanded_image",
							"style": ("ltr",),

							"x" : 200 - 21,
							"y" : 0,

							"image" : "d:/ymir work/ui/pattern/border_c_right.tga",
						},
						{
							"name" : "code_text",
							"type" : "text",

							"x" : 5,
							"y" : 3,

							"text" : uiScriptLocale.PROMO_CODE_HOVER,
							"color" : 0xFF606060,
						},
						{
							"name" : "code_value",
							"type" : "editline",

							"x" : 5,
							"y" : 3,

							"width" : 190,
							"height" : 18,

							"color" : 0xFFDDB811,
							"input_limit" : 32,
							"enable_codepage": 0,

						},

						{
							"name" : "message",
							"type" : "text",

							"x" : 0,
							"y" : -40,

							"text" : uiScriptLocale.PROMO_CODE_TEXT,

							"fontname" : "Tahoma:14b",
							"outline" : True,

							"horizontal_align" : "center",
							"text_horizontal_align" : "center",
						},
					),
				},

				{
					"name" : "accept_button",
					"type" : "button",

					"x" : 0,
					"y" : 50,

					"horizontal_align" : "center",
					"vertical_align" : "bottom",
					"text" : uiScriptLocale.PROMO_CODE_BUTTON,

					"default_image" : ROOT_PATH + "large_button_01.sub",
					"over_image" : ROOT_PATH + "large_button_02.sub",
					"down_image" : ROOT_PATH + "large_button_03.sub",

				},
			),
		},
	),
}